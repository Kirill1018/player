﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace player
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        Uri identificator;
        private void play_med_fail(object sender, ExceptionRoutedEventArgs e) { MessageBox.Show("ошибка во время открытия файла"); }

        private void playorpause_Click(object sender, RoutedEventArgs e)
        {
            if (playorpause.Content.ToString() == "play")
            {
                playorpause.Content = "pause";
                element.Play();
            }
            else
            {
                playorpause.Content = "play";
                element.Pause();
            }
        }

        private void resume_Click(object sender, RoutedEventArgs e) { element.Play(); }

        private void stop_Click(object sender, RoutedEventArgs e) { element.Stop(); }

        private void slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e) { if (element != null) element.Volume = slide.Value; }

        private void start_Click(object sender, RoutedEventArgs e)
        {
            identificator = new Uri(box.Text);
            element.Source = identificator;
        }
    }
}